import mysql.connector
import requests
import json



def lambda_handler(event, context):
    # Retrieve weather data from OpenWeatherMap API
    city_weather_data = {}
    # Connect to MySQL database
    mydb = mysql.connector.connect(
        host="54.163.204.64",
        user="deepak",
        password="Deep@011",
        database="weather"
    )
    cursor = mydb.cursor()


    # Retrieve list of cities from the 'record' table
    cursor.execute("SELECT city FROM record")
    city_list = [row[0] for row in cursor.fetchall()]

    cursor.close()
    mydb.close()
    #fetching the latest data
    for city in city_list:
        url = f'http://api.openweathermap.org/data/2.5/weather?q={city}&appid=091a06fc4d9856db10bfe4a074b61014&units=metric'
        response = requests.get(url)
        city_weather_data[city] = response.json()

    # Connect to MySQL database
    cursor = mydb.cursor()

    # Update weather data in the 'record' table
    for city, weather_data in city_weather_data.items():
        temperature = weather_data['main']['temp']
        sql = f"UPDATE record SET temperature = {temperature} WHERE city = '{city}'"
        cursor.execute(sql)
        mydb.commit()

    cursor.close()
    mydb.close()
